package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.model.Registration;
import com.utility.ConnectionProvider;

public class ProjectDaoImpl {
	//Connection con;
	PreparedStatement psmt;
	ResultSet res;

	

	public int insertReg(Registration register) throws SQLException {
		Connection con = ConnectionProvider.getConnection();
		psmt = con.prepareStatement("insert into userclass values(userid.nextval,?,?,?,?,?,?)");
		psmt.setString(1, register.getEmail());
		psmt.setString(2, register.getName());
		psmt.setString(3, register.getAddress());
		psmt.setString(4, register.getGender());
		psmt.setString(5, register.getPassword());
		psmt.setString(6, register.getRole());

		int x = psmt.executeUpdate();

		return x;
	}

	public int loginValidation(String name, String password) {
		Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		int counter = 0;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select * from userclass");
			while (res.next()) {
				if (res.getString(2).equals(name) && res.getString(6).equals(password)) {
					counter = 1;
					break;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return counter;
		
	}
	
	public ResultSet searchCar(String loc,String sdate,String ldate,int member){
		Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select * from CARRENTALS where CARID in(select distinct CARRENTALS.CARID from CARRENTALS,CARBOOKINGS where CARRENTALS.CARID not in(select carid from CARBOOKINGS))");
			
			
			return res;
			
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	public ResultSet searchHotel(String loc,String sdate,String ldate,int noOfGuest){
		Connection con=ConnectionProvider.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select * from hotel where NUM_OF_ROOOMS_AVAIL>"+noOfGuest+"and HOTELID in(select distinct hotel.HOTELID from HOTELBOOKINGS,hotel where hotel.hotelid not in(select HOTELID from HOTELBOOKINGS))");
			return res;
			
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
