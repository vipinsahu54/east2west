package com.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.model.CarRentals;
import com.model.Flights;
import com.model.Holidays;
import com.model.Hotel;
import com.model.Registration;
import com.model.carBookings;
import com.utility.ConnectionProvider;

public class ProjectDaoImpl {
	// Connection con;
	PreparedStatement psmt;
	ResultSet res;

	public int insertReg(Registration register) throws SQLException {
		Connection con = ConnectionProvider.getConnection();
		psmt = con.prepareStatement("insert into userclass values(userid.nextval,?,?,?,?,?,?)");
		psmt.setString(1, register.getEmail());
		psmt.setString(2, register.getName());
		psmt.setString(3, register.getAddress());
		psmt.setString(4, register.getGender());
		psmt.setString(5, register.getPassword());
		psmt.setString(6, register.getRole());

		int x = psmt.executeUpdate();

		return x;
	}

	public int loginValidation(String name, String password) {
		Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		int counter = 0;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select * from userclass");
			while (res.next()) {
				if (res.getString(2).equals(name) && res.getString(6).equals(password)) {
					counter = 1;
					break;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return counter;

	}

	public ResultSet searchCar(String loc, String sdate, String ldate, int member) {
		Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery(
					"select * from CARRENTALS where CARID in(select distinct CARRENTALS.CARID from CARRENTALS,CARBOOKINGS where CARRENTALS.CARID not in(select carid from CARBOOKINGS) and CARRENTALS.LOCATION='"+loc+"')");

			return res;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;

	}

	public ResultSet searchHotel(String loc, String sdate, String ldate, int noOfGuest) {
		Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select * from hotel where NUM_OF_ROOOMS_AVAIL>" + noOfGuest
					+ "and HOTELID in(select distinct hotel.HOTELID from HOTELBOOKINGS,hotel where hotel.hotelid not in(select HOTELID from HOTELBOOKINGS) and city='"
					+ loc + "')");
			return res;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResultSet searchHolidays(String loc, String checkout, String categories) {
		Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery(
					"select * from PACKAGE_DETAIL where destination='" + loc + "' and categories='" + categories + "'");

			return res;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResultSet searchFlight(String loc, String checkindate, String checkoutdate, int numberofmember) {
		Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select * from FLIGHTS where STARTLOCATION='" + loc + "'");

			return res;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public Flights getFlight(int id) {
		Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select * from FLIGHTS where flightnumber=" + id + "");

			// System.out.println(res.getInt(1)+ res.getString(2)+
			// res.getString(3)+ res.getString(4)+ res.getString(5)+
			// res.getString(6)+ res.getString(7)+ res.getString(8));
			while (res.next()) {
				Flights f = new Flights(res.getInt(1), res.getString(2), res.getString(3), res.getString(4),
						res.getString(5), res.getString(6), res.getString(7), res.getString(8));

				return f;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public Hotel getHotel(int id){
		Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select * from hotel where hotelid=" + id + "");
           
			while (res.next()) {
				
				Hotel h=new Hotel(res.getInt(1), res.getString(2),res.getString(3),res.getInt(4), res.getString(5),res.getInt(6), res.getString(7),res.getInt(8),res.getFloat(9));
			return h;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public CarRentals getCar(int id){
		Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select * from carrentals where carid=" + id + "");
           
			while (res.next()) {
				
				CarRentals cr=new CarRentals(res.getInt(1), res.getString(2),res.getString(3),res.getInt(4), res.getString(5),res.getInt(6), res.getInt(7),res.getString(8));
			return cr;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public Holidays getHoliday(int id){
		return new Holidays();
	}
	
	public Boolean doCarBook(carBookings cb)
	{
		int x = 0;
		try
		{
			Connection con = ConnectionProvider.getConnection();
			String query = "Insert into carbookings values (carId.nextval,?,?,?,?)";
			PreparedStatement prs = con.prepareStatement(query);
			prs.setInt(1, cb.getUserId());
			prs.setInt(2, cb.getCarId());
			prs.setDate(3, (Date) cb.getPickupdate());
			prs.setDate(4,(Date) cb.getDropOffDate());
			 x=prs.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(x>0)
		{
			return true;
			
		}
		else {
			return false;
		}
	}
	
	public String getRole(String name){
		Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select role from userclass where emailid='" + name + "'");
           
			while (res.next()) {
				String path=res.getString(1);
				return path;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}
}
