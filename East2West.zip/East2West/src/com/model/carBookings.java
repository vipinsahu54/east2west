package com.model;

import java.util.Date;

public class carBookings {

	private int bookingId;
	private int userId;
	private int carId;
	private Date pickupdate;
	private Date dropOffDate;
	
	public carBookings() {
	}

	public carBookings(int bookingId, int userId, int carId, Date pickupdate, Date dropOffDate) {
		this.bookingId = bookingId;
		this.userId = userId;
		this.carId = carId;
		this.pickupdate = pickupdate;
		this.dropOffDate = dropOffDate;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public Date getPickupdate() {
		return pickupdate;
	}

	public void setPickupdate(Date pickupdate) {
		this.pickupdate = pickupdate;
	}

	public Date getDropOffDate() {
		return dropOffDate;
	}

	public void setDropOffDate(Date dropOffDate) {
		this.dropOffDate = dropOffDate;
	}

	@Override
	public String toString() {
		return "carBookings [bookingId=" + bookingId + ", userId=" + userId + ", carId=" + carId + ", pickupdate="
				+ pickupdate + ", dropOffDate=" + dropOffDate + "]";
	}
	
	
	
}
