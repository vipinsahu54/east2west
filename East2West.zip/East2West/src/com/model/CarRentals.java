package com.model;

public class CarRentals {

	int carId;
	String model;
	String type;
	int seatingCapacity;
	String aC;
	int ownerId;
	int price;
	String images;
	
	public CarRentals() {
	}

	public String getaC() {
		return aC;
	}

	public void setaC(String aC) {
		this.aC = aC;
	}

	

	


	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public CarRentals(int carId, String model, String type, int seatingCapacity, String aC, int ownerId, int price,
			String images) {
		super();
		this.carId = carId;
		this.model = model;
		this.type = type;
		this.seatingCapacity = seatingCapacity;
		this.aC = aC;
		this.ownerId = ownerId;
		this.price = price;
		this.images = images;
	}

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getSeatingCapacity() {
		return seatingCapacity;
	}

	public void setSeatingCapacity(int seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}

	public String getAC() {
		return aC;
	}

	public void setAC(String aC) {
		this.aC = aC;
	}

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	@Override
	public String toString() {
		return "CarRentals [carId=" + carId + ", model=" + model + ", type=" + type + ", seatingCapacity="
				+ seatingCapacity + ", aC=" + aC + ", ownerId=" + ownerId + ", price=" + price + ", images=" + images
				+ "]";
	}

	
	
}
