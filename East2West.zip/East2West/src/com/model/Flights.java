package com.model;

public class Flights {

	private int flightNumber;
	private String flightCompany ;
	private String startDate ;
	private String startLocation;
	private String endLocation; 
	private String departure; 
	private String arrival;
	private String images;
	public Flights() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Flights(int flightNumber, String flightCompany, String startDate, String startLocation, String endLocation,
			String departure, String arrival, String images) {
		super();
		this.flightNumber = flightNumber;
		this.flightCompany = flightCompany;
		this.startDate = startDate;
		this.startLocation = startLocation;
		this.endLocation = endLocation;
		this.departure = departure;
		this.arrival = arrival;
		this.images = images;
	}
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getFlightCompany() {
		return flightCompany;
	}
	public void setFlightCompany(String flightCompany) {
		this.flightCompany = flightCompany;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStartLocation() {
		return startLocation;
	}
	public void setStartLocation(String startLocation) {
		this.startLocation = startLocation;
	}
	public String getEndLocation() {
		return endLocation;
	}
	public void setEndLocation(String endLocation) {
		this.endLocation = endLocation;
	}
	public String getDeparture() {
		return departure;
	}
	public void setDeparture(String departure) {
		this.departure = departure;
	}
	public String getArrival() {
		return arrival;
	}
	public void setArrival(String arrival) {
		this.arrival = arrival;
	}
	public String getImages() {
		return images;
	}
	public void setImages(String images) {
		this.images = images;
	}
	@Override
	public String toString() {
		return "Flights [flightNumber=" + flightNumber + ", flightCompany=" + flightCompany + ", startDate=" + startDate
				+ ", startLocation=" + startLocation + ", endLocation=" + endLocation + ", departure=" + departure
				+ ", arrival=" + arrival + ", images=" + images + "]";
	}
	
	
}
