package com.model;

public class Hotel {
	private int hotelId;
	private String hotelName;
	private String city;
	private int num_of_rooms_avail;
	private String address;
	private int ownerId;
	private String images;
	private int pricePerDay;
	private float ratings;

	
	public Hotel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPricePerDay() {
		return pricePerDay;
	}

	public void setPricePerDay(int pricePerDay) {
		this.pricePerDay = pricePerDay;
	}

	public float getRatings() {
		return ratings;
	}

	public void setRatings(float ratings) {
		this.ratings = ratings;
	}

	


	public Hotel(int hotelId, String hotelName, String city, int num_of_rooms_avail, String address, int ownerId,
			String images, int pricePerDay, float ratings) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.city = city;
		this.num_of_rooms_avail = num_of_rooms_avail;
		this.address = address;
		this.ownerId = ownerId;
		this.images = images;
		this.pricePerDay = pricePerDay;
		this.ratings = ratings;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getNum_of_rooms_avail() {
		return num_of_rooms_avail;
	}

	public void setNum_of_rooms_avail(int num_of_rooms_avail) {
		this.num_of_rooms_avail = num_of_rooms_avail;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	@Override
	public String toString() {
		return "Hotels [hotelId=" + hotelId + ", hotelName=" + hotelName + ", city=" + city + ", num_of_rooms_avail="
				+ num_of_rooms_avail + ", address=" + address + ", ownerId=" + ownerId + ", images=" + images + "]";
	}
}
