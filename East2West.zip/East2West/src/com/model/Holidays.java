package com.model;

public class Holidays {
	
	private int packageId;
	private String destination;
	private int packageDuration;
	private int price;
	private String location;
	private String categories;
	private String images;
	public Holidays() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Holidays(int packageId, String destination, int packageDuration, int price, String location,
			String categories, String images) {
		super();
		this.packageId = packageId;
		this.destination = destination;
		this.packageDuration = packageDuration;
		this.price = price;
		this.location = location;
		this.categories = categories;
		this.images = images;
	}
	
	@Override
	public String toString() {
		return "Holidays [packageId=" + packageId + ", destination=" + destination + ", packageDuration="
				+ packageDuration + ", price=" + price + ", location=" + location + ", categories=" + categories
				+ ", images=" + images + "]";
	}
	public int getPackageId() {
		return packageId;
	}
	public void setPackageId(int packageId) {
		this.packageId = packageId;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getPackageDuration() {
		return packageDuration;
	}
	public void setPackageDuration(int packageDuration) {
		this.packageDuration = packageDuration;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCategories() {
		return categories;
	}
	public void setCategories(String categories) {
		this.categories = categories;
	}
	public String getImages() {
		return images;
	}
	public void setImages(String images) {
		this.images = images;
	}
	
	
}
