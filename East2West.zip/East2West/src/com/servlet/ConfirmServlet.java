package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.ProjectDaoImpl;
import com.model.CarRentals;
import com.model.carBookings;
import com.utility.ConnectionProvider;


public class ConfirmServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ProjectDaoImpl pd=new ProjectDaoImpl();
        System.out.println("----------inside ConfirmSrevlet Class-------");
        HttpSession session3=request.getSession(false);
        List<CarRentals> l1=(List<CarRentals>)session3.getAttribute("carrental");
        System.out.println(l1);
        String pid=(String)session3.getAttribute("pid");
        System.out.print(pid);
        String loc=(String)session3.getAttribute("carlocation");
        String sdate=(String)session3.getAttribute("carStartDate");
        String ldate=(String)session3.getAttribute("carLastDate");
        String username=(String)session3.getAttribute("name");
        SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
        Date startdate=null;
        Date lastdate=null;
		try {
			startdate = (Date)sdf.parse(sdate);
			lastdate=(Date)sdf.parse(ldate);
		} catch (ParseException e1) {
		}
        
        
        Connection con = ConnectionProvider.getConnection();
		Statement stmt;
		int counter = 0;
		int uid=0;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select userid from userclass where emailid='"+username+"'");
			while (res.next()) {
				uid=res.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
        
       int member=(int)session3.getAttribute("members");
        System.out.println(loc+sdate+"------------");
     pd.doCarBook(new carBookings(101,uid,(Integer.parseInt(pid)), startdate, lastdate));
        
        
       // response.setContentType("application/pdf");
		//PrintWriter out=response.getWriter();
		//Sout.print(loc+sdate+ldate+member);
	
	}
}
