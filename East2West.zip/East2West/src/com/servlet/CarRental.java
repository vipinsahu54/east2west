package com.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.ProjectDaoImpl;
import com.model.CarRentals;


public class CarRental extends HttpServlet {
	 static List<CarRentals> cars=new ArrayList<>();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String loc=request.getParameter("location");
		String startdate=request.getParameter("startdate");
		String lastDate=request.getParameter("lastdate");
		int numberofmember=Integer.parseInt( request.getParameter("members"));
		
		ProjectDaoImpl dao=new ProjectDaoImpl();
		ResultSet rs=dao.searchCar(loc, startdate, lastDate, numberofmember);
		try {
			while (rs.next()){
				cars.add(new CarRentals(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getInt(7), rs.getString(8)));
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		HttpSession session3=request.getSession();
		session3.setAttribute("carrental", cars);
		
		response.sendRedirect("index.jsp?con=car");
	}

}
