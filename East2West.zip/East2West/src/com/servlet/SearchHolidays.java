package com.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.ProjectDaoImpl;
import com.model.Holidays;
import com.model.Hotel;

public class SearchHolidays extends HttpServlet {
	List<Holidays> holidays=new ArrayList<>();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String loc = request.getParameter("location");
		String sdate = request.getParameter("checkout");
		String ldate = request.getParameter("categories");
		
		holidays.clear();
		
		ProjectDaoImpl dao = new ProjectDaoImpl();
		ResultSet res=dao.searchHolidays(loc, sdate, ldate);
		try {
			while(res.next()){
				holidays.add(new Holidays(res.getInt(1),res.getString(2), res.getInt(3),  res.getInt(4), res.getString(5),res.getString(6),res.getString(7)));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		HttpSession session5=request.getSession();
		session5.setAttribute("holidays", holidays);
		
		response.sendRedirect("index.jsp?con=holidays");
	}

}
