package com.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.ProjectDaoImpl;
import com.model.CarRentals;
import com.model.Hotel;

public class SearchHotel extends HttpServlet {
	 static List<Hotel> hotels=new ArrayList<>();
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String loc = request.getParameter("location");
		String sdate = request.getParameter("sdate");
		String ldate = request.getParameter("ldate");
		int noOfGuest = Integer.parseInt(request.getParameter("noOfGuest"));

		System.out.println(loc+sdate+ldate+"----");
		
		ProjectDaoImpl dao = new ProjectDaoImpl();
		ResultSet res=dao.searchHotel(loc, sdate, ldate, noOfGuest);
		try {
			while(res.next()){
				hotels.add(new Hotel(res.getInt(1),res.getString(2), res.getString(3), res.getInt(4), res.getString(5), res.getInt(6), res.getString(7), res.getInt(8),res.getFloat(9)));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Hotel hotel : hotels) {
			System.out.println(hotel);
		}
		HttpSession session4=request.getSession();
		session4.setAttribute("hotel", hotels);
		
		response.sendRedirect("index.jsp?con=hotel");
	}

}
