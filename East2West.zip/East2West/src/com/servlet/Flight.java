package com.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.ProjectDaoImpl;
import com.model.Flights;


public class Flight extends HttpServlet {
	 static List<Flights> flight=new ArrayList<>();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		flight.clear();
		
		String loc=request.getParameter("location");
		String checkindate=request.getParameter("checkindate");
		String checkoutdate=request.getParameter("checkoutdate");
		int numberofmember=Integer.parseInt( request.getParameter("noOfGuets"));
		
		System.out.println(loc);
		ProjectDaoImpl dao=new ProjectDaoImpl();
		ResultSet rs=dao.searchFlight(loc, checkindate, checkoutdate, numberofmember);
		try {
			while (rs.next()){
				flight.add(new Flights(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7), rs.getString(8)));
					
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		HttpSession session6=request.getSession(false);
		session6.setAttribute("flights", flight);	
		response.sendRedirect("index.jsp?con=flights");
	}

}
